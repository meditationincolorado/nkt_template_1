<article id="banner-cta" class="hidden">
	<a id="close">&#8679;</a>
	<span class='text'>
		<span class="mobile-hidden">You can find </span> <a href="./true-happiness"><span class="mobile-hidden">True</span> Happiness</a> | 
	</span>
	<span class='text'>
		<span class="mobile-hidden">Become a</span> <a href="./membership">Member<span class="mobile-shown">ship</span></a> |
	</span>
	<span class='text'>
		Try <a data-cta="signup" class="cta"><span class="highlight">Free</span></a>
	</span>
</article>

<div id="reveal-cta" class="">
	<span>CO</span>
</div>